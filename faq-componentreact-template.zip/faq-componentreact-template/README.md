# FAQ component - React template

A Pen created on CodePen.io. Original URL: [https://codepen.io/frontendeval/pen/BaJGzYg](https://codepen.io/frontendeval/pen/BaJGzYg).

